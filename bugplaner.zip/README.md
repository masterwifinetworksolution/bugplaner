# Bug Planer Simaster

## Overview
- Auto on and off mode plane


## Download Links (Archive)
- [GitHub Releases](https://github.com)

## Credits
- masterwifinetworksolution

## Extras
- Donations: [PayPal](https://paypal.me/myarachma92) - [Sociabuzz](https://sociabuzz.com/masterwifinetworksolution) - [Ko-fi](https://ko-fi.com/masterwifinetworksolution)
- Source Code: [GitHub](https://github.com/masterwifinetworksolution/bugplaner)
