#!/system/bin/sh

# Jalankan skrip bugplaner.sh di latar belakang
/system/etc/bugplaner.sh &