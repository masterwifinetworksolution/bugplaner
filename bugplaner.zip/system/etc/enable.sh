#!/system/bin/sh
STATUSFILE="/data/adb/modules/bugplaner/system/etc/bugplaner-status.txt"
echo "enabled" > "$STATUSFILE"
echo "Script diaktifkan."
