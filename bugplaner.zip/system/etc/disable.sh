#!/system/bin/sh
STATUSFILE="/data/adb/modules/bugplaner/system/etc/bugplaner-status.txt"
echo "disabled" > "$STATUSFILE"
echo "Script dinonaktifkan."
